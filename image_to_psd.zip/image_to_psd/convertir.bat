@echo off
REM Glisse une ou plusieurs images JPEG/PNG sur ce fichier.
python "%~dp0image_to_psd.py" %*
pause
